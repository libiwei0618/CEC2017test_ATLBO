clear
clc
close all
addpath input_data

%% ��������
Max_iteration = 1000;           
N = 30;                        
Function_name = 'F10';        
[lb, ub, dim, fobj] = CEC2017(Function_name);

%% �Ż�
% ��ʼ����Ⱥλ��
X = initialization(N, dim, ub, lb);
[Best_score, Best_pos, ATLBO_Curve] = ATLBO(X, N, Max_iteration, lb, ub, dim, fobj);

%% ��ͼ
% ����Ŀ�꺯��ֵ�仯����ͼ
figure;
t = 1:Max_iteration;
semilogy(t, ATLBO_Curve, 'r-', 'linewidth', 2); 
title(Function_name); 
xlabel('Iteration'); 
ylabel('Best score');
axis fill
% grid on
box on
legend('ATLBO');
set(gcf,'color','w')

%% ��ʾ���
display(['The optimal solution of ', Function_name, ' is: ', num2str(Best_pos)]);
display(['The optimal value of ', Function_name, ' is : ', num2str(Best_score)]);

