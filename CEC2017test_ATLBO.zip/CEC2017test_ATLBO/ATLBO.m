%%
function [fitnessgbest, gbest, zz] = ATLBO(X, N, maxgen, lb, ub, dim, fobj)
%% 参数初始化
    stunum = N;
    d = dim;
    STUnew = zeros(stunum,d);%更新之后
    STUbest = zeros(maxgen,d);
    fitness =  zeros(stunum,1);
    fitnessnew = zeros(stunum,1);%更新之后的适应度
    TF = round(1+rand);%取值1，2
    for i = 1:N
        fitness(i) = fobj(X(i,:));
    end
    [~,minfitnessvalindex] = min(fitness);%适应度对应的最小值，适应度最小值对应的索引值
%%

    Rmax = 0.996;
    Rmin = 0.004;
    k = 2;
    for iter=1:maxgen
        x1(iter) = iter;
        wt(iter) = (Rmax-Rmin)*(iter/maxgen)^k+Rmin;
    end

for iter=1:maxgen 
    TEA=X(minfitnessvalindex,:);%教师,最优
    M=mean(X);%平均值
    Difference_Mean=rand*(TEA-TF*M);
    
    %教师阶段
    for i=1:stunum
          STUnew(i,:)=X(i,:)+Difference_Mean;
        for j=1:d
            if STUnew(i,j) < lb 
                STUnew(i,j) =lb + (ub - lb)*rand;
            end
            if STUnew(i,j) > ub
                STUnew(i,j) = lb + (ub - lb)*rand;
            end
        end
        fitnessnew(i) = fobj(STUnew(i,:));
        if fitnessnew(i) < fitness(i)%学生在教学阶段后适应度减小则更新
            X(i,:) = STUnew(i,:);
            fitness(i) = fitnessnew(i);
        end
    end
  %%  
    %学生学习阶段
    for i=1:stunum
        Kindex = setdiff(1:stunum,i);
        Tindex = randperm(length(Kindex));
        Xj = X(Kindex(Tindex(1)),:);
        jfval = fitness(Kindex(Tindex(1)));
        if fitness(i)<jfval
            STUnew(i,:)=X(i,:)+wt(iter)*(X(i,:)-Xj);
        else
            STUnew(i,:)=X(i,:)+wt(iter)*(Xj-X(i,:));
        end
%             Xnew(i,:)=X(i,:)+wt(iter)*(X(i,:)-Xj);
%         else
%             Xnew(i,:)=X(i,:)+wt(iter)*(Xj-X(i,:));
%         end
        
        for j=1:d
            if STUnew(i,j) < lb
                STUnew(i,j) = lb + (ub - lb)*rand;
            end
            if STUnew(i,j) > ub
                STUnew(i,j) = lb + (ub - lb)*rand;
            end
        end
        
        fitnessnew(i) = fobj(STUnew(i,:));
        if fitnessnew(i) < fitness(i)
            X(i,:)=STUnew(i,:);
            fitness(i)=fitnessnew(i);
        end
    end
    %%
    % 课后训练阶段
    for i=1:stunum
    
        TEA1=normrnd(TEA,sqrt(abs(TEA-X(i,:))));
        
        STUnew(i,:)=TEA1+rand*(TEA-X(i,:));
        for j=1:d
            if STUnew(i,j) < lb 
                STUnew(i,j) =lb + (ub - lb)*rand;
            end
            if STUnew(i,j) > ub
                STUnew(i,j) = lb + (ub - lb)*rand;
            end
        end
        fitnessnew(i) = fobj(STUnew(i,:));
        if fitnessnew(i)<fitness(i)
            X(i,:)=STUnew(i,:);
            fitness(i)=fitnessnew(i);
        end
     end
 
[fitnessgbest,minfitnessvalindex] = min(fitness);
gbest = X(minfitnessvalindex,:);
zz(iter) = fitnessgbest;
end
